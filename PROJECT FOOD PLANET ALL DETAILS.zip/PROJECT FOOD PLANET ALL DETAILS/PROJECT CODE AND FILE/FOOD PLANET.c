#include<stdio.h>
#include<windows.h>
#include<process.h>
#include<stdlib.h>
#include<conio.h>
#include<string.h>
#define BKSP 8



/**Declearation**/
    char res_name[10];
    char prfoods[100];
    char loc[200];
    char ffi[50];
    char locsearch[100];
    char dis[20];
    char foods[100];
    char fch[100];
    char rup[300];
    char uni[300];
    char bar[300];
    char cho[300];
    char amt[300];
    char lon[300];
    char bot[300];
    char rup[300];
    char noth[300];
    char adminch[100];
    char password[100];
    int kkh=0;






char st[100],st2[100];
FILE *fp;
    int k, l;

    char ch;
char file_name[100];

void file_print(FILE *fp)
{
    char dis[4000];
    system("cls");
    while(fgets(dis,10000,fp)){
    printf("%s\n", dis);
    }
}
void file_rename(char *new_name)
{
    strcpy(file_name,new_name);
    strcat(file_name,".txt");

}

FILE *create(char *mode)
{
    FILE *fp;
    fp = fopen(file_name,mode);
    return fp;
}

void loading()
{
    int i;

        printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t\t\t");
        printf("Loading ");

        printf(" .");
        for(i = 1; i <= 500000; i++);
        printf(".");
        for(i = 1; i <= 500000; i++);
        printf(".");
        for(i = 1; i <= 500000; i++);

        system("cls");

}
int exist(char *str)
{
    strlwr(str);
    char A[1000];
    FILE *fp;
    fp=fopen("list.txt","r");
    int check=0;
    while(fgets(A,1000,fp))
    {
        strlwr(A);
        if(strncmp(A,str,strlen(str))==0)
        {

            check=1;
            break;
        }
    }
    fclose(fp);
    return check;
}

void deletetext(char *str)
{
    char list[1000],list1[1000];
    strlwr(str);
    FILE *fp;
    fp=fopen("list.txt","r");
    FILE *fp1;
    fp1=fopen("templist.txt","a");
    while(fgets(list,1000,fp))
    {
        strcpy(list1,list);

        strlwr(list1);

        if(strncmp(str,list1,strlen(str))==0)
        {
            continue;
        }
        fprintf(fp1,"%s",list);
    }
    fclose(fp);
    fclose(fp1);
//    FILE *fp2;
//    fp2=fopen("list.txt","w");
//    fclose(fp2);

    FILE *fp3;
    fp3=fopen("templist.txt","r");
    FILE *fp4;
    fp4=fopen("list.txt","w");
    char A[1000];
    while(fgets(A,1000,fp3))
    {
        fprintf(fp4,"%s",A);
    }
    fclose(fp3);
    fclose(fp4);
    FILE *fp5;
    fp5=fopen("templist.txt","w");
    fclose(fp5);


    //printf("\t\t\tSuccessfully deleted!!!\n");
}





void file_note(FILE *fp)
{
    char nt[2000], n[100];
    gets(nt);
    printf("Please Enter your name to give Rating/Comment : ");
    gets(n);
    printf("Enter you Rating/Comment : ");
    gets(nt);
    fprintf(fp, "\n\n\n Rating/Comment : %s by %s", nt, n);
}

void file_write(FILE *fp, char *name)
{

    gets(dis);
    strcpy(dis, name);
    printf("Location : ");
    strcpy(loc,locsearch);
    gets(loc);
    printf("Favourite Food Item : ");
    gets(ffi);
    fprintf(fp,"\n\t\t\t%s Restaurant\n\t\t-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_\n\n\tLocation\t\t: %s\n\tSpecial Food Item : %s",dis,loc,ffi);
    printf("\nPlease Enter The Food Names  \n");
    fprintf(fp,"\n\n\t\t\t\tFood Items Available\n");
    food:
        kkh++;

        printf("Food %d : ",kkh );
        gets(foods);
        printf("Price of The Food(In Numeric or English) : ");
        gets(prfoods);

        fprintf(fp,"\n\tFood %d : %s",kkh,foods);
        fprintf(fp,"\n\tPrice = %s TAKA",prfoods);
        printf("\n[Press (1) To Add NEW Food Item\nPress Any KEY To Go To Continue_]");
        gets(fch);
        if(strcmp(fch,"1")==0)
        {
            goto food;
        }
        fprintf(fp,"\n\n\t\t\t[NB : IT IS APPLICATION OF BARISAL CITY.]\n\n");
        fprintf(fp,"\n\n\t\t\tRoute to Locate The Restaurant Easily\n");
        printf("\t\tEnter the Route to Locate The Restaurant Easily\n\n");
        printf("\nRoute From Rupatoli\t: ");
        gets(rup);
        fprintf(fp,"\n\tRoute From Rupatoli\t: %s",rup);
        printf("Route From University\t: ");
        gets(uni);
        fprintf(fp,"\n\tRoute From University\t: %s",uni);
        printf("Route From Nothullabad\t: ");
        gets(noth);
        fprintf(fp,"\n\tRoute From Nothullabad\t: %s",noth);
        printf("Route From Barisal Sadar: ");
        gets(bar);
        fprintf(fp,"\n\tRoute From Barisal Sadar: %s",bar);
        printf("Route From Choumatha\t: ");
        gets(cho);
        fprintf(fp,"\n\tRoute From Choumatha\t: %s",cho);
        printf("Route From Amtola\t: ");
        gets(amt);
        fprintf(fp,"\n\tRoute From Amtola\t: %s",amt);
        printf("Route From LonchGhat\t: ");
        gets(lon);
        fprintf(fp,"\n\tRoute From LonchGhat\t: %s",lon);
        printf("Route From Bottola\t: ");
        gets(bot);
        fprintf(fp,"\n\tRoute From Bottola\t: %s",rup);
        fclose(fp);


}




/**MENU PRINT**/

int main()
{
    system("COLOR 3F");
    mainlop();


                         /**MAIN MENU**/

    main:
    system("cls");
    printcase();
    char choice[100];
    scanf("%s",choice);





    /**PROJECT FOOD PLANET ADMIN PANEL**/





     if(strcmp(choice,"5")==0)
    {
       loading();
        remove:
            system("cls");
        printf("\n\n\t\t\t***This is Admin Panel***");
        printf("\n\n\n\tAre You Admin?");
        printf("\n\t(1)Yes");
        printf("\n\t(2)NO");
        printf("\n*NO will take you back to the main menu*");
        printf("\n\n\tEnter your choice : ");

        scanf("%s",adminch);
        if(strcmp(adminch,"1")==0)
        {
            system("cls");
            printf("\n\n\n\n\n\n\t\t\t\t###WELCOME TO ADMIN PANEL###\n\n\n");
            printf("Press Any Key To Continue ");
            char wertr[10];
            scanf("%s",wertr);
            getchar();

            system("cls");
            printf("\n\n\tPlease Enter Your Name : ");
            char myname[100];
            gets(myname);
            passcode:
            printf("\n\n\tEnter the Password Given From Authority : ");
            scanf("%s",password);
            system("cls");
            FILE *fpp;
            char chpass[100];
            fpp=fopen("password.txt","r");
            fscanf(fpp,"%[^\n]",chpass);
            if(strcmp(password,chpass)==0)
            {
                loading();
                adminpan:
                system("cls");
                printf("\n\n\t\t\t\tWelcome %s\n\n\n",myname);
                printf("\n\tPress (1) To ADD a Restaurant");
                printf("\n\tPress (2) To Remove a Restaurant");
                printf("\n\tPress (3) To Change Password");
                printf("\n\tPress (0) To EXIT");
                printf("\n\n\tPress Another Key To Go To Main Menu");
                printf("\n\tEnter Your Choice : ");
                char apch[100];
                scanf("%s",apch);


                    /**PROJECT_FOOD_PLANET_ADDING NEW RESTAURANT*/



      if(strcmp(apch,"1")==0)
    {

        char addchoice[100];
        addnewres:
        system("cls");
        printf("\t\t\tAdding New Restaurant :\n\t\t_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_\n\n");
        printf("\n Enter Restaurant Name : ");
        getchar();
        scanf("%[^\n]", st);

        strcpy(st2, st);
        strcpy(file_name,st);
        strcat(file_name,".txt");
        //file_rename(st);

        FILE *fp;
        fp = fopen(file_name,"r");
        //fp = create("r");
        if(fp==0){
                FILE *fp10;
        fp10=fopen("list.txt","a");
        fprintf(fp10,"%s\n",st);
        fclose(fp10);

        fclose(fp);
        strcpy(file_name,st2);
        strcat(file_name,".txt");

        //file_rename(st2);
        FILE *fp;
        fp = fopen(file_name,"w");
        file_write(fp, st);
        fclose(fp);
        printf("\n\n*****Record has been written successfully !!!***** \n");
        printf("\n\n[Press (1) to Add New Restaurant ");
        printf("\n\n[Press (2) to go to Admin Panel ");
        printf("\nPress Any Key To Get Back To Main Menu.] \n");
        gets(addchoice);
        if(strcmp(addchoice,"1")==0)
        {
            kkh=0;

            goto addnewres;
        }
           else if(strcmp(addchoice,"2")==0)
        {
            loading();

            goto adminpan;
        }
          else
        {
            loading();
            loading();
             goto main;
        }
        //fclose(fp);
        }

        else {
                getchar();
        printf("\n\nThe Restaurant already exists !!!\nPlease Enter the exact new Code of the Restaurant.");

        printf("\n\n[Press (1) to Add New Restaurant ");
        printf("\nPress Any Key To Get Back To Admin Panel.] \n");
        char addchoice2[100];
        gets(addchoice2);
        if(strcmp(addchoice2,"1")==0)
        {

            goto addnewres;
        }
        else
        {
             goto adminpan;
        }

        fclose(fp);
        }

    }

/**FINISH**/


           /***Deleting**/
           else if(strcmp(apch,"2")==0)
           {
               removefile();
               deletef:
    system("cls");

printf("\n Enter Restaurant Name You Want to delete: ");
        getchar();
        scanf("%[^\n]", st);


        strcpy(st2, st);
        strcpy(file_name,st);
        strcat(file_name,".txt");
        //file_rename(st);

        FILE *fp;
        fp = fopen(file_name,"r");
        //fp = create("r");
        if(fp!=0){
                if(exist(st)==1)
        {
            deletetext(st);
        }
        fclose(fp);
        strcpy(file_name,st2);
        strcat(file_name,".txt");
        //file_rename(st2);
        FILE *fp;
        fp = fopen(file_name,"w");
        fprintf(fp,"\n\n\tNot Available!!");
        //file_write(fp, st);
        fclose(fp);
        printf("\n\n\t\t\t*****Deleted successfully !!!***** \n");
        printf("\n\n[Press (1) to Delete More ");

        printf("\nPress Any Key To Get Back To Admin Panel.] \n");
          char        addchoice[100];
       scanf("%s",addchoice);
        if(strcmp(addchoice,"1")==0)
        {

            goto deletef;
        }
          else
        {
            loading();
             goto adminpan;
        }
        fclose(fp);
        }

        else {
                getchar();
        printf("\n\nThe Restaurant dosen't exists !!!");

        printf("\n\n[Press (1) to Delete More ");
        printf("\nPress Any Key To Get Back To Admin Panel.] \n");
        char addchoice2[100];
        gets(addchoice2);
        if(strcmp(addchoice2,"1")==0)
        {

            goto deletef;
        }
        else
        {
             goto adminpan;
        }

        fclose(fp);
        }





           }
           /**FINISH**/








                    else if(strcmp(apch,"0")==0)
                    {
                        return 0;
                    }


                    /**PASSWORD CHANGE */

                    else if(strcmp(apch,"3")==0)
                    {
                        char oldpass[100];
                        system("cls");
                        printf("\n\n\t\t\t\tTo Change Password  ");
                               ddd:
                        printf("\n\n\t\t\tEnter the old password : ");
                        scanf("%s",oldpass);
                        if(strcmp(chpass,oldpass)==0)
                        {
                            printf("\n\n\t\tMATCHED!!\n\nEnter The New Password : ");
                            char newpass[100];
                            scanf("%s",newpass);

                            FILE *fp1;
                            fp1=fopen("password.txt","w");
                            fprintf(fp1,"%s",newpass);
                            fclose(fp1);
                            system("cls");
                            printf("\n\n\n\n\n\t\t\t\t\tPassword Changed\n\nPress Any Key To Continue_");
                            char zxc[100];
                            scanf("%s",zxc);
                            if(strcmp(zxc,"1")==0)
                             {
                            goto adminpan;
                              }
                             else

                            {
                            goto adminpan;
                           }

                        }
                        else
                        {
                            system("cls");
                            printf("\n\n\n\tYou have entered your old password incorrectly!!!\n\n");
                            printf("Press any Key To Continue");
                            char fgh[100];
                            scanf("%s",fgh);
                            system("cls");
                            loading();
                            goto ddd;
                        }
                    }


/**************FINISH*********/








             else
             {

             system("cls");
             loading();

              goto main;
             }

            }
            else
            {
                system("cls");
                char qwe[100];
                printf("\n\n\tWrong Password!!\n\n\tPress (1) to go to Main Menu\n\tPress Another Key To Continue_");
                scanf("%s",qwe);
                if(strcmp(qwe,"1")==0)
                {
                    goto main;
                }
                else

                {
                    system("cls");
                    goto passcode;
                }
            }
            fclose(fpp);
        }
        else if(strcmp(adminch,"2")==0)
        {
            loading();
            goto main;
        }
        else
        {
            system("cls");
            printf("\n\nWRONG KEYWORDS\n\nPress Any Key To Continue _");
            char asd[100];
            scanf("%s",asd);
            goto remove;
        }
    }






/**PROJECT FOOD PLANET DETAILS OF A RESTAURANT**/
else if(strcmp(choice,"2")==0)
{
    details:

    system("cls");
    printf("\n\n\t\t\t\t\t  ==============================");
    printf("\n\t\t\t\t              >>>>> FOOD PLANET <<<<<");
    printf("\n\t\t\t\t\t  ==============================\n\n");
    printf("To Know Restaurant Details.\n\nYou Need to Enter Restaurant Name _ ");
    char gotodet[100];
        getchar();
        scanf("%[^\n]", st);

//        char ch[1000];
//        strcpy(ch,st);
//        strcat(ch,".txt");
//        FILE *fp3;
//        fp3=fopen(ch,"r");
//        char ch1[1000];
//        while(fgets(ch1,1000,fp3))
//        {
//            printf("%s",ch1);
//        }
//        fclose(fp3);

        file_rename(st);
        strcpy(file_name,st);
        strcat(file_name,".txt");
        FILE *fp;
        fp = fopen(file_name,st);
        fp = create("r");
        if(fp==0){
                system("cls");
        printf("\n\nNot found !!!");
        printf("\nPress(1)to go to Main Menu");
        printf("\nPress Another Key To Enter Again");
        printf("\nEnter Choice : ");
        scanf("%s",gotodet);
            if (strcmp(gotodet,"1")==0)
            {
               goto main;
            }
            else
           {
                goto details;
            }


        fclose(fp);
        }
    else {
            file_print(fp);
            printf("\n\nPress any key to get back to main menu. ");
            fclose(fp);

    }





    printf("\n\nPress(1)If You Want To Another Details\nPress Another Key To Go To MAIN MENU\nEnter Choice : ");

    char det[100];
    scanf("%s",det);
    if(strcmp(det,"1")==0)
    {
        system("cls");
        goto details;

    }
    else {
            system("cls");
    goto main;
    }
}







            /**Project_Food_Planet_ABOUT**/


    else if(strcmp(choice,"6")==0)
    {
        system("cls");
        start1:
            printf("\n\n\n\n\t\t\t\t(1)About Developer");
            printf("\n\t\t\t\t(2)About Project");
            printf("\n\t\t\t\t(0)EXIT");
            printf("\n\t\t\t\t( )Backspace to Go Back");
            printf("\n\n\t\t\tEnter Your Choice : ");
            char abch[100];
            char ac;
            char bks1;
            bks1=getch();
                if(bks1==BKSP)
                {
                    goto main;
                }
            scanf("%s",abch);
            if(strcmp(abch,"1")==0)
            {
                system("cls");
                about1();
                char ac1;
               char bks2;
                bks2=getch();
                if(bks2==BKSP)
                {
                    system("cls");
                    goto start1;
                }
                char ac2;
                getchar();
                goto main;
            }
            else if(strcmp(abch,"2")==0)
            {
                system("cls");
                about2();
                char ac2;
               char bks3;
                bks3=getch();
                if(bks3==BKSP)
                {
                    system("cls");
                    goto start1;
                }
                char ac3;
                getchar();
                goto main;

            }
            else if(strcmp(abch,"0")==0)
            {
                return 0;
            }
            else
            {
               int p3,n2=0;
               lope2 :
                     n2++;
                     printf("   Wrong Keyword");
                     for (p3=0;p3<=50000000;p3++);
                     printf(" Please");
                     for (p3=0;p3<=100000000;p3++);
                     printf(" Enter");
                     for (p3=0;p3<=100000000;p3++);
                     printf(" The");
                     for (p3=0;p3<=100000000;p3++);
                     printf(" Choice Again");
                     for (p3=0;p3<=100000000;p3++);
                     printf("");
                     for (p3=0;p3<=100000000;p3++);
                     printf("");
                     if (n2<=3){
                     system("cls");
                     goto lope2;
                     }

                      goto start1;
                     }


    }
    else if(strcmp(choice,"0")==0)
    {
        return 0;
    }
/**FINISH*/







    /**LOCATION SEARCH**/
    else if(strcmp(choice,"4")==0)
    {
        system("cls");
        printf("\n\n\t This Search is only for Advertisements\n\n");
        printf("It will show you the nearby famous and permanent restaurants\nYou can not get access to edit this\n\n\n");
        location:
            printf("\tEnter Your Location (Barisal City) : ");
            char locres[100];
            scanf("%s",locres);
        if(strcmp(locres,"Nothullabad")==0||strcmp(locres,"NOTHULLABAD")==0||strcmp(locres,"nothullabad")==0||strcmp(locres,"nOthullabad")==0)
            {
                printf("\n");
                printf("\n\t(1)Dhansiri");
                printf("\n\t(2)Bangali");
                printf("\n\t(3)Bismillah");
                printf("\n\t(4)Golpata");
                printf("\n\t(5)Sumaita");
                printf("\n\t(6)BFC");



                    printf("\n\n\n[If you want to know more Press (1)\nPress Another Key To Go To MAIN MENU _");
    char op1[100];
    scanf("%s",op1);
    if(strcmp(op1,"1")==0)
    {
        system("cls");
        goto location;

    }
    else {
            system("cls");
            loading();
    goto main;
    }
            }
        else if(strcmp(locres,"Choumatha")==0||strcmp(locres,"choumatha")==0||strcmp(locres,"CHOUMATHA")==0||strcmp(locres,"cHoumatha")==0)
            {
                printf("\n");
                printf("\n\t(1)Lake View Restaurant");
                printf("\n\t(2)JFC");





                 printf("\n\n\n[If you want to know more Press (1)\nPress Another Key To Go To MAIN MENU _");
    char op2[100];
    scanf("%s",op2);
    if(strcmp(op2,"1")==0)
    {
        system("cls");
        goto location;

    }
    else {
            system("cls");
    goto main;
    }
            }
       else if(strcmp(locres,"Rupatoli")==0||strcmp(locres,"RUPATOLI")==0||strcmp(locres,"rupatoli")==0||strcmp(locres,"rUpatoli")==0)
            {
                printf("\n");
                printf("\n\t(1)Vojon Bilash");
                printf("\n\t(2)Gulshan");
                printf("\n\t(3)Khabar Hotel");






                printf("\n\n\n[If you want to know more Press (1)\nPress Another Key To Go To MAIN MENU _");
    char op3[100];
    scanf("%s",op3);
    if(strcmp(op3,"1")==0)
    {
        system("cls");
        goto location;

    }
    else {
            system("cls");
    goto main;
    }
            }
        else if(strcmp(locres,"Kornokathi")==0||strcmp(locres,"KORNOKATHI")==0||strcmp(locres,"kornokathi")==0||strcmp(locres,"kOrnokathi")==0)
            {
                printf("\n");
                printf("\n\t(1)Cafe Campus");
                printf("\n\t(2)Hungry Times");




                  printf("\n\n\n[If you want to know more Press (1)\nPress Another Key To Go To MAIN MENU _");
    char op4[100];
    scanf("%s",op4);
    if(strcmp(op4,"1")==0)
    {
        system("cls");
        goto location;

    }
    else {
            system("cls");
            loading();
    goto main;
    }

            }
            else if(strcmp(locres,"Sadar")==0||strcmp(locres,"SADAR")==0||strcmp(locres,"sadar")==0||strcmp(locres,"sAdar")==0)
            {
                printf("\n");
                printf("\n\t(1)Hundy Korai");
                printf("\n\t(2)Sokal Sondha");
                printf("\n\t(3)Hot Plate");
                printf("\n\t(4)Royal");
                printf("\n\t(5)Hotel Grand Park");


                printf("\n\n\n[If you want to know more Press (1)\nPress Another Key To Go To MAIN MENU _");
    char op5[100];
    scanf("%s",op5);
    if(strcmp(op5,"1")==0)
    {
        system("cls");
        goto location;

    }
    else {
            system("cls");
    goto main;
    }
            }
            else if(strcmp(locres,"Amtola")==0||strcmp(locres,"AMTOLA")==0||strcmp(locres,"amtola")==0||strcmp(locres,"aMtola")==0)
            {
                printf("\n");
                printf("\n\t(1)Gournodi Sweets");



                printf("\n\n\n[If you want to know more Press (1)\nPress Another Key To Go To MAIN MENU _");
    char op6[100];
    scanf("%s",op6);
    if(strcmp(op6,"1")==0)
    {
        system("cls");
        goto location;

    }
    else {
            system("cls");
    goto main;
    }
            }
        else if(strcmp(locres,"Lonchghat")==0||strcmp(locres,"LONCHGHAT")==0||strcmp(locres,"lonchghat")==0||strcmp(locres,"lonchGhat")==0)
            {
                printf("\n");
                printf("\n\t(1)Muslim Chittagong Restaurants");




                 printf("\n\n\n[If you want to know more Press (1)\nPress Another Key To Go To MAIN MENU _");
    char op7[100];
    scanf("%s",op7);
    if(strcmp(op7,"1")==0)
    {
        system("cls");
        goto location;

    }
    else {
            system("cls");
    goto main;
    }

            }
            else if(strcmp(locres,"Bottola")==0||strcmp(locres,"BOTTOLA")==0||strcmp(locres,"bottola")==0||strcmp(locres,"bOttola")==0)
            {
                printf("\n");
                printf("\n\t(1)Dhansiri");





                printf("\n\n\n[If you want to know more Press (1)\nPress Another Key To Go To MAIN MENU _");
    char op8[100];
    scanf("%s",op8);
    if(strcmp(op8,"1")==0)
    {
        system("cls");
        goto location;

    }
    else {
            system("cls");
    goto main;
    }
            }
            else
            {
                system("cls");
                printf("\n\n\n\tSorry!!Your Location is not available in our database");
                printf("\n\nPress Any Key To Continue_");
                char cvbn[10];
                scanf("%s",cvbn);
                system("cls");
                goto location;
            }
    }





/******FINISH*******/



/**PROJECT FOOD PLANET ADD RATING**/




    else if(strcmp(choice,"3")==0)
    {
        addrating:
        system("cls");
        printf("\t\t\tGive us a RATING:\n\t\t_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_\n\n");
        printf("\n\n[Give your rating as Comments]\n\n");
        printf("\nEnter the Restaurant Name : ");
        //getchar();
        scanf("%[^\n]", st);


//        file_rename(st);
//        strcpy(file_name,st);
//        strcat(file_name,".txt");
//        FILE *fp;s
//        fp = fopen(file_name,st);
//        fp = create("r");


        strcpy(st2, st);
        file_rename(st);
        fp = create("r");
        if(fp==0){
        printf("\n\nNot found !!!\nIf you want to add Rating please enter valid Name.");
        printf("\nPress Any Key To Continue");
        getchar();
        goto addrating;
        fclose(fp);
        }
        else{
        file_rename(st2);
        fp = create("a");
        file_note(fp);
        printf("\nThank you for your rating !!!");
        }
        fclose(fp);
        printf("\n\nPress Any Key To Get Back To Main Menu.");
        getchar();
        loading();
        goto main;
    }


/**FINISH**/




/**PROJECT FOOD PLANET SHOWING ALL RESTAURANT LIST*/



else if(strcmp(choice,"1")==0)
{
    system("cls");
    printf("\n");

    printf("\n\n\n\t\t\tList of All Restaurant\n\n\n");
    FILE *fp;
    fp=fopen("list.txt","r");
    char list[1000];
    int serial=1;
    while(fgets(list,1000,fp))
    {
        printf("\t%d\t%s",serial,list);
        serial++;
    }
    fclose(fp);


    getchar();
    printf("\n\nPress(1)To View Details\nYou can also view details from Menu \nPress Another Key To Go To Main Menu\nEnter Choice : ");
    char showl[100];
    scanf("%s",showl);
    if(strcmp(showl,"1")==0)
    {
        system("cls");
        goto details;

    }
    else {
            system("cls");
            loading();
    goto main;
    }


/**FINISH**/

    }


  else
    {
        int p2,n1=0;
    lope1 :
        n1++;
    printf("   Wrong Keyword Please Enter The Choice Again");
    for (p2=0;p2<=50000000;p2++);
    printf(" ");
    for (p2=0;p2<=100000000;p2++);
    printf(" ");
    for (p2=0;p2<=100000000;p2++);
    printf(" ");
    for (p2=0;p2<=100000000;p2++);
    printf("  ");
    for (p2=0;p2<=100000000;p2++);
    printf(" ");
    for (p2=0;p2<=100000000;p2++);
    printf(" ");
    if (n1<=2){
            system("cls");
        goto lope1;
    }
    loading();

        goto main;
    }
}











/**Functions**/

/**Function_About**/





/**Functions_Rating**/


































void about1()
{
    printf("\n\n\t\t\t>>>>> FOOD PLANET <<<<<< ");
    printf("\n\n\tDeveloper Name : Pranta Kumar Biswas ");
    printf("\n\n\tAcademic Background :\n ");
    printf("\n\t\t\t\tUniversity of Barisal ");
    printf("\n\t\t  Department of Computer Science & Engineering");
    printf("\n\t\t\t\t Session(2016-2017)");
    printf("\n\t\t\t       Class Roll : 17CSE028 ");
    printf("\n\t\t\t  1st Semester Exam Roll : CSE021");
    printf("\n\n\tOthers \n\n\t\tHobby : PhotoGraphy");
    printf("\n\t\tWebsite : Wordpress & Flickr");
    printf("\n\n\t\tAim In Life");
    printf("\n\t\tGoverment Worker (If Possible in Programmer Post)");
    printf("\n\n\n\t\t\tSpecial Thanks To:");
    printf("\n\n\t\t\t\t ==================================================\n");
    printf("\n\t\t\t\t|   \t      Md .Mostafijur Rahman\t\t  |");
    printf("\n\t\t\t\t|   \t   Lecturer & Student Advisor\t\t  |");
    printf("\n\t\t\t\t|  Department of Computer Science & Engineering   |");
    printf("\n\t\t\t\t|   \t      University of Barisal.\t\t  |");
    printf("\n\n\t\t\t\t ==================================================\n");
    printf("\n\n\n\t\t>>>>>> Thanks For Using this Project <<<<<<\n\n");
    printf("\nPress any Key To Go to Main Menu");
    printf("\nPress Backspace to Go Back");


}


void about2()
{
    printf("\n\t\t\t\t>>>>>> FOOD PLANET <<<<<,");
    printf("\n\n\tFeatures\n");
    printf("\n\t\tThis is a Project for Food Lovers\n\t\t* ");
    printf("View The Details of any Restaurant\n\t\t");
    printf("* Easily remove any Restaurant\n\t\t");
    printf("* Add any Restaurant\n\t\t* Locating a Restaurant\n\t\t");
    printf("* Easily know about the details of the restaurant\n\t\t");
    printf("\n\n\t This project was given by my honorable teacher \n");
    printf("\n\t\t\t\tMd. Mostafijur Rahman ");
    printf("\n\t\t\t\tLecturer & Student Advisor");
    printf("\n\t\t\t\tUniversity of Barisal ");
    printf("\n\t\t\t\tDepartment of Computer Science & Engineering");
    printf("\n\n\tInstructed by My Teacher");
    printf("\n\tSimple Help by My Brother\n\n");
    printf("Youtube\t: Learning Removing a file details in C Programming\n");
    printf("Google\t: Adding a Removable File in C Programming\n\t\t\tFor Information");
    printf("\n\nPress any Key To Go to Main Menu");
    printf("\nPress Backspace to Go Back");
}





void printcase()
{
    printf("\n\n\t\t\t\t\t  ==============================");
    printf("\n\t\t\t\t        >>>>> Welcome to FOOD PLANET <<<<<");
    printf("\n\t\t\t\t\t  ==============================");
    printf("\n\n\n\n\t\t\t\t\t\t   MAIN MENU");
    printf("\n\n\t\t\t\t==================================================\n");
    printf("\n\t\t\t\t|\t    (1) List of All Restaurants\t\t  |");
    printf("\n\t\t\t\t|\t    (2) Details of All Restaurants\t  |");
    printf("\n\t\t\t\t|\t    (3) Give Your Rating\t\t  |");
    printf("\n\t\t\t\t|\t    (4) Location Search\t\t\t  |");
    printf("\n\t\t\t\t|\t    (5) Admin Panel\t\t\t  |");
    printf("\n\t\t\t\t|\t    (6) About\t\t\t\t  |");
    printf("\n\t\t\t\t|\t    (0) EXIT\t\t\t\t  |");
    printf("\n\n\t\t\t\t==================================================\n");


    printf("\n\t\t\t\tEnter Your Choice : ");
}





void mainlop()
{
    printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\t\tWELCOME TO FOOD PLANET\n\n");
    int p,n=0;
    lope :
        n++;

    for (p=0;p<=50000000;p++);
    printf("");
    for (p=0;p<=100000000;p++);
    printf("");
    for (p=0;p<=100000000;p++);
    printf("");
    for (p=0;p<=100000000;p++);
    printf("");
    for (p=0;p<=100000000;p++);
    printf("");
    for (p=0;p<=100000000;p++);
    printf("");
    if (n<=1){
            system("cls");
        goto lope;
    }


    int pl,w=0;
    lop :
        w++;
    printf("\t\t\t\n\n\n\n\n\n\n\n\n\t\t\t\t\tPlease Wait\n");

    for (pl=0;pl<=50000000;pl++);
    printf("\t\t\t\t      .");
    for (pl=0;pl<=100000000;pl++);
    printf(" .");
    for (pl=0;pl<=100000000;pl++);
    printf(" .");
    for (pl=0;pl<=100000000;pl++);
    printf(" .");
    for (pl=0;pl<=100000000;pl++);
    printf(" .");
    for (pl=0;pl<=100000000;pl++);
    printf(" .");
    for (pl=0;pl<=100000000;pl++);
    printf(" .");
    for (pl=0;pl<=100000000;pl++);
    printf(" .");
    if (w<=1){
            system("cls");
        goto lop;
    }
    system("cls");
}


void removefile()
{
//    char f_name[100];
//    char rf_name[100];
//    printf("\n\n\n\tEnter the restaurant name you want to delete :");
//    gets(f_name);
//    strcpy(rf_name,f_name);
//    strcat(rf_name,".txt");
//    FILE *fp;
//    fp=fopen(rf_name,"w");
//    fprintf(fp,"Not available!!");
////    fclose(fp);


    }

/**              PRANTA KUMAR BISWAS               ***

   CLASS ROLL : 17CSE028
   EXAM ROLL : CSE021
       UNIVERSITY OF BARISAL
   DEPARTMENT OF COMPUTER SCIENCE AND ENGINEERING
   */
